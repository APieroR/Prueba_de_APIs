import Groq from "groq-sdk";

const groq = new Groq({
  apiKey: ""
});

async function pruebaIA() {

  const chatCompletion = await groq.chat.completions.create({
    messages: [
      {
        role: "user",
        content: "Explica que es la inteligencia artificial en pocas palabras"
      }
    ],
    model: "llama-3.1-8b-instant"
  });

  console.log(chatCompletion.choices[0].message.content);
}

pruebaIA();